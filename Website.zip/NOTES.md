            <!--TEMPLATE-->
            <div class="article">
                <h2 class="article-title">Article Title</h2>
                <div class="article-meta">
                    Date | Category
                </div>
                <img src="path/to/thumbnail.png" alt="Thumbnail" class="thumbnail" onclick="showImageModal(this)">
                <p class="article-content">
                    Article content goes here.
                </p>
            </div>